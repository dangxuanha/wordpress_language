Class ST Login
+ Proccess login form (use shortcode)
[st_login login_redirect="" logout_redirect="" register_link="" profile_link="" lost_pass_link=""]
+ Disable link in login form
[st_login login_redirect="" logout_redirect="" register_link="" profile_link="" lost_pass_link="" disable_link="y"]
+ Proccess lostpass form (use shortcode)
[st_lost_password]
+ Proccess login form modal (use shortcode)
[st_login_modal login_success_redirect="" register_success_redirect="" logout_redirect=""]


Class ST Register
+ Proccess register form (use shortcode)
[st_register login_link="" success_redirect=""]
+ Disable link in register form 
[st_register login_link="" success_redirect="" disable_link="y"]
+ Proccess profile form (use shortcode)
[st_profile login_link=""]
