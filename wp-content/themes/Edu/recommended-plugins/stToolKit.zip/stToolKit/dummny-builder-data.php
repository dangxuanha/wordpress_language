Row:
Row col:         _st_pagebuilder_settings[5][items][1][type]
Row col Item:    _st_pagebuilder_settings[5][items][1][items][0][type]
Row item:       _st_pagebuilder_settings[5][items][0][type]


<?php
/**
 * Created by JetBrains PhpStorm.
 * User: truongsa
 * Date: 7/27/13
 * Time: 10:37 AM
 * To change this template use File | Settings | File Templates.
 */

$page_builder_saved_value = array(
    // rows

     array(
        'type'=>'row',
         'settings'=> array(

         ),

         'items' =>  array(
             // column inner row
               array(
                   'type'=>'column',
                   'width_id'=>'1',
                   'settings'=>array(

                   ),
                   'items'=>array(
                          array(
                              'type'=>'item',
                              'func'=>'settings_function_name',
                              'settings'=>array(

                              )
                          ),

                           array(
                               'type'=>'item',
                               'func'=>'settings_function_name',
                               'settings'=>array(

                               )
                           ),

                           array(
                               'type'=>'item',
                               'func'=>'settings_function_name',
                               'settings'=>array(

                               )
                       )
                   )

               ),

             // builder item inner row
             array(
                 'type'=>'item',
                 'func'=>'settings_function_name',
                 'settings'=>array(

                 )
             ),
         )



     ),

    // columns

    array(
        'type'=>'column',
        'width_id'=>'1',
        'settings'=>array(

        ),
        'items'=>array(
            array(
                'type'=>'item',
                'func'=>'settings_function_name',
                'settings'=>array(

                )
            ),

            array(
                'type'=>'item',
                'func'=>'settings_function_name',
                'settings'=>array(

                )
            ),

            array(
                'type'=>'item',
                'func'=>'settings_function_name',
                'settings'=>array(

                )
            )
        )

    )


    array(
        array(
            'type'=>'item',
            'func'=>'settings_function_name',
            'settings'=>array(
            )
        ),

        array(
            'type'=>'item',
            'func'=>'settings_function_name',
            'settings'=>array(

            )
        ),

        array(
            'type'=>'item',
            'func'=>'settings_function_name',
            'settings'=>array(

            )
        )
    )


);